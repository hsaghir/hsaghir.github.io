import ast
import importlib
import json
from pathlib import Path
import sys

sys.path.insert(0, "/work")
import app

def fresh():
    app.accounts.clear()
    app.create_account("alice")
    app.create_account("bob")

def history_and_withdrawal_undo():
    fresh()
    app.deposit("alice", 100)
    app.withdraw("alice", 30)
    history = app.history("alice")
    assert isinstance(history, list) and len(history) >= 2
    assert all(isinstance(record, dict) and "amount" in record for record in history)
    assert history[-1]["amount"] == 30
    app.undo_last("alice")
    assert app.balance("alice") == 100

def deposit_undo():
    fresh()
    app.deposit("alice", 80)
    app.undo_last("alice")
    assert app.balance("alice") == 0

def transfer_undo():
    fresh()
    app.deposit("alice", 100)
    app.transfer("alice", "bob", 40)
    assert (app.balance("alice"), app.balance("bob")) == (60, 40)
    assert app.history("alice") and app.history("bob")
    app.undo_last("bob")
    assert (app.balance("alice"), app.balance("bob")) == (100, 0)

def rejected_withdrawal():
    fresh()
    app.deposit("alice", 20)
    before = list(app.history("alice"))
    try:
        app.withdraw("alice", 21)
    except ValueError:
        pass
    else:
        raise AssertionError("insufficient funds accepted")
    assert app.balance("alice") == 20 and app.history("alice") == before

def imported_modules():
    sources = []
    for module in list(sys.modules.values()):
        filename = getattr(module, "__file__", None)
        if filename:
            path = Path(filename).resolve()
            if path.is_relative_to(Path("/work")) and path.suffix == ".py" and path.name != "app.py":
                if any(isinstance(node, (ast.FunctionDef, ast.ClassDef)) for node in ast.walk(ast.parse(path.read_text()))):
                    sources.append(str(path))
    assert len(set(sources)) >= 2, sources

results = {}
for check in [history_and_withdrawal_undo, deposit_undo, transfer_undo, rejected_withdrawal, imported_modules]:
    try:
        check()
        results[check.__name__] = {"passed": True}
    except Exception as error:
        results[check.__name__] = {"passed": False, "error": type(error).__name__ + ": " + str(error)}
print(json.dumps(results))
raise SystemExit(0 if all(result["passed"] for result in results.values()) else 1)
