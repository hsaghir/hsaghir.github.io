import pytest
import app

def setup_function(fn):
    app.accounts.clear()

def test_create_and_deposit():
    app.create_account("alice")
    assert app.deposit("alice", 100) == 100

def test_withdraw():
    app.create_account("bob")
    app.deposit("bob", 50)
    assert app.withdraw("bob", 20) == 30

def test_transfer():
    app.create_account("a")
    app.create_account("b")
    app.deposit("a", 100)
    assert app.transfer("a", "b", 40) == (60, 40)

def test_insufficient():
    app.create_account("c")
    with pytest.raises(ValueError):
        app.withdraw("c", 10)
