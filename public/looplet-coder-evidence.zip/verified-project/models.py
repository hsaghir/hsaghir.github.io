from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class Account:
    """Account state and chronological transaction history."""

    name: str
    balance: int = 0
    history: list[dict[str, Any]] = field(default_factory=list)