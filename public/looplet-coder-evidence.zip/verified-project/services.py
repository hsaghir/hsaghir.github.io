from __future__ import annotations

from collections.abc import MutableMapping
from typing import Any, Iterator

from models import Account


class AccountsView(MutableMapping[str, int]):
    """Mapping view that exposes account balances like the legacy dict."""

    def __init__(self, ledger: "Ledger") -> None:
        self._ledger = ledger

    def __getitem__(self, key: str) -> int:
        return self._ledger.get_account(key).balance

    def __setitem__(self, key: str, value: int) -> None:
        if key in self._ledger._accounts:
            self._ledger._accounts[key].balance = value
            return
        self._ledger._accounts[key] = Account(name=key, balance=value)

    def __delitem__(self, key: str) -> None:
        del self._ledger._accounts[key]

    def __iter__(self) -> Iterator[str]:
        return iter(self._ledger._accounts)

    def __len__(self) -> int:
        return len(self._ledger._accounts)

    def clear(self) -> None:
        self._ledger.clear()


class Ledger:
    """Service object that manages accounts and transaction history."""

    def __init__(self) -> None:
        self._accounts: dict[str, Account] = {}
        self.accounts = AccountsView(self)
        self._next_txn_id = 1

    def clear(self) -> None:
        self._accounts.clear()
        self._next_txn_id = 1

    def get_account(self, name: str) -> Account:
        return self._accounts[name]

    def create_account(self, name: str) -> str:
        if name in self._accounts:
            raise ValueError("exists")
        self._accounts[name] = Account(name=name)
        return name

    def deposit(self, name: str, amount: int) -> int:
        self._validate_amount(amount)
        account = self.get_account(name)
        account.balance += amount
        account.history.append({"type": "deposit", "amount": amount})
        return account.balance

    def withdraw(self, name: str, amount: int) -> int:
        self._validate_amount(amount)
        account = self.get_account(name)
        if account.balance < amount:
            raise ValueError("insufficient funds")
        account.balance -= amount
        account.history.append({"type": "withdraw", "amount": amount})
        return account.balance

    def balance(self, name: str) -> int:
        return self.get_account(name).balance

    def transfer(self, src: str, dst: str, amount: int) -> tuple[int, int]:
        self._validate_amount(amount)
        src_account = self.get_account(src)
        dst_account = self.get_account(dst)
        if src_account.balance < amount:
            raise ValueError("insufficient funds")

        txn_id = self._next_transaction_id()
        src_account.balance -= amount
        dst_account.balance += amount
        src_account.history.append(
            {"type": "transfer", "amount": amount, "direction": "out", "other": dst, "transaction_id": txn_id}
        )
        dst_account.history.append(
            {"type": "transfer", "amount": amount, "direction": "in", "other": src, "transaction_id": txn_id}
        )
        return (src_account.balance, dst_account.balance)

    def history(self, name: str) -> list[dict[str, Any]]:
        account = self.get_account(name)
        return [record.copy() for record in account.history]

    def undo_last(self, name: str) -> int:
        account = self.get_account(name)
        if not account.history:
            raise ValueError("no history")

        record = account.history[-1]
        record_type = record["type"]
        amount = record["amount"]

        if record_type == "deposit":
            account.balance -= amount
            account.history.pop()
            return account.balance

        if record_type == "withdraw":
            account.balance += amount
            account.history.pop()
            return account.balance

        if record_type == "transfer":
            self._undo_transfer(name, record)
            return account.balance

        raise ValueError("unknown operation")

    def _undo_transfer(self, name: str, record: dict[str, Any]) -> None:
        account = self.get_account(name)
        other = self.get_account(record["other"])
        amount = record["amount"]
        transaction_id = record["transaction_id"]

        if record["direction"] == "out":
            account.balance += amount
            other.balance -= amount
        else:
            account.balance -= amount
            other.balance += amount

        self._pop_transfer_record(account, transaction_id)
        self._pop_transfer_record(other, transaction_id)

    @staticmethod
    def _pop_transfer_record(account: Account, transaction_id: int) -> None:
        for index in range(len(account.history) - 1, -1, -1):
            if account.history[index].get("transaction_id") == transaction_id:
                account.history.pop(index)
                return
        raise ValueError("transfer history mismatch")

    @staticmethod
    def _validate_amount(amount: int) -> None:
        if amount <= 0:
            raise ValueError("amount must be positive")

    def _next_transaction_id(self) -> int:
        transaction_id = self._next_txn_id
        self._next_txn_id += 1
        return transaction_id