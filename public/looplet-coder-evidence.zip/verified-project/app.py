from services import Ledger

_ledger = Ledger()
accounts = _ledger.accounts


def create_account(name: str) -> str:
    """Create a new account and return its name."""
    return _ledger.create_account(name)


def deposit(name: str, amount: int) -> int:
    """Deposit funds into an account and return the new balance."""
    return _ledger.deposit(name, amount)


def withdraw(name: str, amount: int) -> int:
    """Withdraw funds from an account and return the new balance."""
    return _ledger.withdraw(name, amount)


def balance(name: str) -> int:
    """Return the current account balance."""
    return _ledger.balance(name)


def transfer(src: str, dst: str, amount: int) -> tuple[int, int]:
    """Transfer funds and return the updated source and destination balances."""
    return _ledger.transfer(src, dst, amount)


def history(name: str) -> list[dict[str, object]]:
    """Return chronological transaction history for an account."""
    return _ledger.history(name)


def undo_last(name: str) -> int:
    """Undo the most recent operation affecting an account."""
    return _ledger.undo_last(name)